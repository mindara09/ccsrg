<?php require 'header.php'; ?>

<div class="container">
	<br><br><br>
	<div class="card">
		<div class="card-body">
			<h1 class="card-title">Input Materi</h1><br>

			<form method="post" enctype="multipart/form-data">
				<div class="input-group input-group-sm mb-3">
			  <div class="input-group-prepend">
			    <span class="input-group-text" id="inputGroup-sizing-sm">Judul</span>
			  </div>
			  <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
			</div>
			<div class="input-group mb-3">
			  <div class="input-group-prepend">
			    <label class="input-group-text" for="inputGroupSelect01">Sub Kategori</label>
			  </div>
			  <select class="custom-select" id="inputGroupSelect01">
			    <option selected>Choose...</option>
			    <option value="pendahuluan">Pendahuluan</option>
			    <option value="wh">Wireless Hacking</option>
			    <option value="webh">Web Hacking</option>
			    <option value="hs">Hacking Server</option>
			    <option value="hts">Hacking Tutorial Series</option>
			    <option value="htws">Hacking Tools in Windows Series</option>
			  </select>
			</div>
			<div class="input-group input-group-sm mb-3">
			  <div class="input-group-prepend">
			    <span class="input-group-text" id="inputGroup-sizing-sm">Deskripsi</span>
			  </div>
			 <textarea class="form-control"></textarea>
			</div>
			<div class="input-group mb-3">
			  <div class="input-group-prepend">
			    <span class="input-group-text" id="inputGroupFileAddon01">Foto Thumbnail</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
			    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			  </div>
			</div>
			<div class="input-group mb-3">
			  <div class="input-group-prepend">
			    <span class="input-group-text" id="inputGroupFileAddon01">Upload Video</span>
			  </div>
			  <div class="custom-file">
			    <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
			    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			  </div>
			</div>
			<button class="btn btn-primary" name="submit">Submit</button>
			</form>
			
		</div>
	</div>
</div>



<?php require 'footer.php'; ?>