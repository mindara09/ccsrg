<?php require 'header.php'; ?>

<section class="engine"><a href="https://mobirise.ws/p">open source web page builder</a></section><section class="header11 cid-rSbnZYA3eD mbr-fullscreen mbr-parallax-background" id="header11-v">

    <!-- Block parameters controls (Blue "Gear" panel) -->
    
    <!-- End block parameters -->

    <div class="mbr-overlay" style="opacity: 0.6; background-color: rgb(0, 0, 0);">
    </div>
    <div class="container align-left">
        <div class="media-container-column mbr-white col-md-12">
            <h3 class="mbr-section-subtitle py-3 mbr-fonts-style display-5"></h3>
            <h1 class="mbr-section-title py-3 mbr-fonts-style display-1">KONTAK KAMI !</h1>
            <p class="mbr-text py-3 mbr-fonts-style display-5">
                JIKA ANDA MENGALAMI APLIKASI YANG RUSAK/TIDAK BEKERJA SEBAGAI MESTI NYA, ANDA BISA KIRIM MASALAH TERSEBUT KE EMAIL KAMI, YAITU :<br>info.csrg.id@gmail.com<br>DENGAN SUBJECT : CCSRG | &lt;Masalah Kalian&gt;<br>MAKA KAMI AKAN MEMBALAS EMAIL ANDA.<br>MOHON BERI PENJELASAN YANG JELAS TENTANG KERUSAKAN YANG ANDA ALAMI, AGAR KAMI PAHAM APA YANG ANDA ALAMI/MENGGANTI APLIKASI CCSRG DENGAN BARU.<br><br><br>TERIMA KASIH, BEST REGARDS ;).<br>TIM DEV CSRG&nbsp;</p>
            <div class="mbr-section-btn py-4"><a class="btn btn-md btn-primary display-4" href="https://mobirise.com">LEARN MORE</a></div>
        </div>
    </div>

    
</section>


<?php require 'footer.php'; ?>