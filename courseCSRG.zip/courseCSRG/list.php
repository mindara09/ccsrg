<?php require 'header.php'; ?>


<section class="engine"><a href="https://mobirise.ws/a">best free site builder</a></section><section class="mbr-section content5 cid-rR3fE7Wdns mbr-parallax-background" id="content5-j">

    

    

    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-2">| Penetration Testing |</h2>
                <h3 class="mbr-section-subtitle align-center mbr-light mbr-white pb-3 mbr-fonts-style display-5">Penetration Testing adalah suatu kegiatan dimana seseorang mencoba mensimulasikan serangan yang bisa dilakukan terhadap jaringan organisasi / perusahaan tertentu untuk menemukan kelemahan yang ada pada sistem jaringan tersebut. Berikut modul pembelajaran Penetration Testing</h3>
                
                
            </div>
        </div>
    </div>
</section>

<section class="toggle1 cid-rSbluqhPQq" id="toggle1-m">

    

    
        <div class="container">
            <div class="media-container-row">
                <div class="col-12 col-md-8">
                    <div class="section-head text-center space30">
                       <h2 class="mbr-section-title pb-5 mbr-fonts-style display-2">
                            List Course Penetration Testing</h2>
                    </div>
                    <div class="clearfix"></div>
                    <div id="bootstrap-toggle" class="toggle-panel accordionStyles tab-content">
                        <div class="card">
                            <div class="card-header" role="tab" id="headingOne">
                                <a role="button" class="collapsed panel-title text-black" data-toggle="collapse" data-parent="#accordion" data-core="" href="#collapse1_10" aria-expanded="false" aria-controls="collapse1">
                                    <h4 class="mbr-fonts-style display-7">
                                        <span class="sign mbr-iconfont mbri-arrow-down inactive"></span>Pendahuluan</h4>
                                </a>
                            </div>
                            <div id="collapse1_10" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-7">
                                       Berikut pengantar dari Penetration Testing <a href="dPenetrationTesting.html">DISINI</a>!<br></p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingOne">
                                <a role="button" class="collapsed panel-title text-black" data-toggle="collapse" data-parent="#accordion" data-core="" href="#collapse1_xx" aria-expanded="false" aria-controls="collapse1">
                                    <h4 class="mbr-fonts-style display-7">
                                        <span class="sign mbr-iconfont mbri-arrow-down inactive"></span>Information Gathering</h4>
                                </a>
                            </div>
                            <div id="collapse1_xx" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-7">
                                       Berikut pengantar dari Penetration Testing <a href="dPenetrationTesting.html">DISINI</a>!<br></p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingTwo">
                                <a role="button" class="collapsed panel-title text-black" data-toggle="collapse" data-parent="#accordion" data-core="" href="#collapse2_10" aria-expanded="false" aria-controls="collapse2">
                                    <h4 class="mbr-fonts-style display-7">
                                        <span class="sign mbr-iconfont mbri-arrow-down inactive"></span>Wireless Hacking</h4>
                                </a>

                            </div>
                            <div id="collapse2_10" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingTwo">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-7">
                                       * Hacking Wi-Fi<br>* Man In the Middle Attack</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingThree">
                                <a role="button" class="collapsed panel-title text-black" data-toggle="collapse" data-parent="#accordion" data-core="" href="#collapse3_10" aria-expanded="false" aria-controls="collapse3">
                                    <h4 class="mbr-fonts-style display-7">
                                        <span class="sign mbr-iconfont mbri-arrow-down inactive"></span>Web Hacking</h4>
                                </a>
                            </div>
                            <div id="collapse3_10" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingThree">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-7">* SQL Injection<br>* Blind SQL Injection<br>* XSS (Reflected)<br>* XSS (Stored)<br>* XSS (DOM)<br>* File Upload Vulnerability<br>* Local File Inclusion<br>* OS Command Execution<br>* Bruteforce<br>* CSRF<br></p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingThree">
                                <a role="button" class="collapsed panel-title text-black" data-toggle="collapse" data-parent="#accordion" data-core="" href="#collapse4_10" aria-expanded="false" aria-controls="collapse4">
                                    <h4 class="mbr-fonts-style display-7">
                                        <span class="sign mbr-iconfont mbri-arrow-down inactive"></span>Hacking Server</h4>
                                </a>
                            </div>
                            <div id="collapse4_10" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingThree">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-7">* Bruteforce SSH Server<br>* Bruteforce MySQL Server<br>* Bruteforce FTP Server<br>* Bruteforce Telnet Server<br>* Hacking Samba Server</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingThree">
                                <a role="button" class="collapsed panel-title text-black" data-toggle="collapse" data-parent="#accordion" data-core="" href="#collapse5_10" aria-expanded="false" aria-controls="collapse5">
                                    <h4 class="mbr-fonts-style display-7">
                                        <span class="sign mbr-iconfont mbri-arrow-down inactive"></span>Hacking Tutorial Series</h4>
                                </a>
                            </div>
                            <div id="collapse5_10" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingThree">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-7">* Metasploit<br>* Phising<br>* Hacking Windows 7, 8, dan 10<br>* Hacking Android&nbsp;</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingThree">
                                <a role="button" class="collapsed panel-title text-black" data-toggle="collapse" data-parent="#accordion" data-core="" href="#collapse6_10" aria-expanded="false" aria-controls="collapse6">
                                    <h4 class="mbr-fonts-style display-7">
                                        <span class="sign mbr-iconfont mbri-arrow-down inactive"></span>Hacking Tools in Windows Series</h4>
                                </a>
                            </div>
                            <div id="collapse6_10" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingThree">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-7">
                                       Web Vulnerability Scanners :<br>* Commix<br>* dodotpwn<br>* fimap<br>* golismero<br>* jSQL<br>* nikto<br>* padbuster<br>* sqlmap<br>* vega<br>* wpscan<br>* zap OWASP<br>Web Application Proxies :<br>* burpsuite<br>* zap OWASP<br>CMS Vulnerability Scanners :<br>* cmsmap<br>* droopescan<br>* joomscan<br>* wpscan<br>* vbscan<br>Web Crawlers :<br>* dirbuster<br>* burpsuite<br>Information Gathering :<br>* ipscan<br>* dnsrecon<br>* golismero<br>* instarecon<br>* nmap<br>Exploitation Tools :<br>* beefproject<br>* crackmapexec<br>* metasploit<br>* sqlmap<br>Password Attacks:<br>* burpsuite<br>* findmyhash<br>* hashidentifier<br>* hydra<br>Android Security :<br>* androbugs<br>* androapkinfo<br>* androwarn<br>* apktool<br>* bytecodeviewer<br>Reverse Engineering :<br>Stress Testing :<br>Sniffing :<br>Forensics Tools :<br>Wireless Attacks :</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>

<?php require 'footer.php'; ?>