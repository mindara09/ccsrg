<!DOCTYPE html>
<html >
<head>
  <!-- Site made with Mobirise Website Builder v4.6.5, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.6.5, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logo4.png" type="image/x-icon">
  <meta name="description" content="">
  <title>Computer Security &amp; Researcher Group</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons-bold/mobirise-icons-bold.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
  <section class="cid-rQWWj0b1gj mbr-fullscreen mbr-parallax-background" id="header2-3">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(35, 35, 35);"></div>

    <div class="container align-center">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">Course | CSRG</h1>
                
                <p class="mbr-text pb-3 mbr-fonts-style display-5">
                    Dengan adanya Course CSRG ini, dapat menjadi pembelajaran bagi mahasiswa STMIK "AMIKBANDUNG" maupun umum yang giat dalam belajar dunia IT, salah satunya <strong>Penetration Testing</strong>, <strong>Web Developer, System Administration&nbsp;</strong>dan <strong>Networking </strong>dengan disediakan beberapa Tools untuk membantu belajar praktek yang sudah di sediakan.</p>
                <div class="mbr-section-btn"><a class="btn btn-md btn-success display-4" href="https://mobirise.com">Cek Materi Kuy</a>
                    <a class="btn btn-md btn-white-outline display-4" href="https://mobirise.com">About Us</a></div>
            </div>
        </div>
    </div>
    <div class="mbr-arrow hidden-sm-down" aria-hidden="true">
        <a href="#next">
            <i class="mbri-down mbr-iconfont"></i>
        </a>
    </div>
</section>

<section class="engine"><a href="https://mobirise.ws/b">best free site creator</a></section><section class="features8 cid-rR0Net9rws" id="features8-i">

    

    <div class="mbr-overlay" style="opacity: 0.2; background-color: rgb(35, 35, 35);">
    </div>

    <div class="container">
        <div class="media-container-row">

            <div class="card  col-12 col-md-6 col-lg-3">
                <div class="card-img">
                    <span class="mbr-iconfont mbrib-lock"></span>
                </div>
                <div class="card-box align-center">
                    <h4 class="card-title mbr-fonts-style display-7">
                        Penetration Testing</h4>
                    <p class="mbr-text mbr-fonts-style display-7">Penetration Testing ini akan membahas semua seputar kegiatan penetration testing (pentest) mulai dari pengenalan penetration testing, mencari informasi target, mencari kerentanan target, menyerang target hingga membuat laporan dalam kegiatan pentest<br></p>
                    <div class="mbr-section-btn text-center"><a href="listPenetrationTesting.html" class="btn btn-secondary display-4">
                            More
                        </a></div>
                </div>
            </div>

            <div class="card  col-12 col-md-6 col-lg-3">
                <div class="card-img">
                    <span class="mbr-iconfont mbrib-arrow-next"></span>
                </div>
                <div class="card-box align-center">
                    <h4 class="card-title mbr-fonts-style display-7">
                        Web Developer</h4>
                    <p class="mbr-text mbr-fonts-style display-7">Web Developer ini akan membahas semua tentang Front End &nbsp;Developer, mulai dari bagaimana menggunakan desain website dan Back End Developer untuk mengelola bagian server. Seperti input data dan lain - lain</p>
                    <div class="mbr-section-btn text-center"><a href="https://mobirise.com" class="btn btn-secondary display-4">
                            More
                        </a></div>
                </div>
            </div>

            <div class="card  col-12 col-md-6 col-lg-3">
                <div class="card-img">
                    <span class="mbr-iconfont mbrib-globe-2"></span>
                </div>
                <div class="card-box align-center">
                    <h4 class="card-title mbr-fonts-style display-7">
                        Networking</h4>
                    <p class="mbr-text mbr-fonts-style display-7">
                       Disini kita akan belajar mengenai semua jaringan. Mulai dari Cisco, yaitu cara merancang simulasi jaringan menggunakan Cisco Packet Tracer dan Mikrotik, yaitu mempraktekan cara men-<em>setting</em>&nbsp;Mikrotik dan juga Keamanan Routernya.</p>
                    <div class="mbr-section-btn text-center">
                        <a href="https://mobirise.com" class="btn btn-secondary display-4">
                            More
                        </a>
                    </div>
                </div>
            </div>

            <div class="card  col-12 col-md-6 col-lg-3">
                <div class="card-img">
                    <span class="mbr-iconfont mbrib-add-submenu"></span>
                </div>
                <div class="card-box align-center">
                    <h4 class="card-title mbr-fonts-style display-7">
                        System Administration Server</h4>
                    <p class="mbr-text mbr-fonts-style display-7">Dalam System Adminsitration Server ini bagaimana kita memasang aplikasi yang di butuhkan oleh server seperti SSH Server, FTP Server, MySQL Server hingga memasang keamanan pada server seperti penggunaan ModSecurity. Snort dan lain - lain.</p>
                    <div class="mbr-section-btn text-center">
                        <a href="https://mobirise.com" class="btn btn-secondary display-4">
                            More
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="cid-rSbewxyHmb" id="footer5-l">

    

    

    <div class="container">
        <div class="media-container-row">
            <div class="col-md-3">
                <div class="media-wrap">
                    <a href="https://mobirise.com/">
                       <img src="assets/images/artboard-3-972x972.png" alt="Mobirise" title="">
                    </a>
                </div>
            </div>
            <div class="col-md-9">
                <p class="mbr-text align-right links mbr-fonts-style display-7">
                    <a href="about-us.html" class="text-black">ABOUT</a>&nbsp; &nbsp; &nbsp; <a href="index.html#features8-i" class="text-black">MATERI</a>&nbsp; &nbsp; &nbsp;<a href="contact-us.html" class="text-black">CONTACT</a>
                </p>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-md-6 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                        © Copyright 2018 <strong><em>Computer Security &amp; Researcher Group</em></strong>&nbsp;- All Rights Reserved
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="social-list align-right">
                        <div class="soc-item">
                            <a href="https://twitter.com/mobirise" target="_blank">
                                <span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="https://www.facebook.com/pages/Mobirise/1616226671953247" target="_blank">
                                <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social"></span>
                            </a>
                        </div>
                        
                        
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  
  
</body>
</html>