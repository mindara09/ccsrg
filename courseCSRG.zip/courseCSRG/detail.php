<?php require 'header.php'; ?>



<section class="engine"><a href="https://mobirise.ws/l">free html website creator</a></section><section class="header7 cid-rQXQAf6dKJ" id="header7-d">

    

    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(0, 0, 0);">
    </div>

    <div class="container">
        <div class="media-container-row">

            <div class="media-content align-right">
                <h1 class="mbr-section-title mbr-white pb-3 mbr-fonts-style display-5">
                    Introduction Penetration Testing</h1>
                <div class="mbr-section-text mbr-white pb-3">
                    <p class="mbr-text mbr-fonts-style display-7">
                        Intro with background color, paddings and a video on the right. Mobirise helps you cut down development time by providing you with a flexible website editor with a drag and drop interface.
                    </p>
                </div>
                
            </div>

            <div class="mbr-figure" style="width: 125%;"><iframe class="mbr-embedded-video" src="video/test.mp4?loop=0&amp;autoplay=0" width="1280" height="720" frameborder="0" allowfullscreen></iframe></div>

        </div>
    </div>
</section>

<section class="features18 popup-btn-cards cid-rR0vcWNYxU" id="features18-g">

    

    
    <div class="container">
        
        
        <div class="media-container-row pt-5 ">
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper ">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="https://mobirise.com" class="btn btn-primary display-4">Learn More</a>
                        </div>
                        <img src="assets/images/01.jpg" alt="Mobirise">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            Information Gathering</h4>
                        
                    </div>
                </div>
            </div>
            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="https://mobirise.com" class="btn btn-primary display-4">Learn More</a>
                        </div>
                        <img src="assets/images/02.jpg" alt="Mobirise">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            Vulnerability Assesment</h4>
                        
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-wrapper">
                    <div class="card-img">
                        <div class="mbr-overlay"></div>
                        <div class="mbr-section-btn text-center">
                            <a href="https://mobirise.com" class="btn btn-primary display-4">Learn More</a>
                        </div>
                        <img src="assets/images/03.jpg" alt="Mobirise">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">
                            Exploitation</h4>
                        
                    </div>
                </div>
            </div>

            
        </div>
    </div>
</section>

<?php require 'footer.php'; ?>